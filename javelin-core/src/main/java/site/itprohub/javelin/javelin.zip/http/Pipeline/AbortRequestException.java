package site.itprohub.javelin.http.Pipeline;

public class AbortRequestException extends RuntimeException {
    
}
