package site.itprohub.javelin.startup;

import java.util.HashSet;
import java.util.Set;

import org.reflections.Reflections;

import site.itprohub.javelin.http.tomcat.JavelinEmbeddedTomcatServer;

public class JavelinStarter {

    public static String BASE_PACKAGE;

    private Set<BaseAppStarter> starters = new HashSet<>();

    static {
        // 静态初始化块，在类加载时执行
    }

    public void run(Class<?> appClass, String[] args, AppStartupOption option) throws Exception
    {
        BASE_PACKAGE = appClass.getPackage().getName(); // 自动获取包名
        System.out.println("Javelin starting from package: " + BASE_PACKAGE);

        javelinInit();

        JavelinEmbeddedTomcatServer server = new JavelinEmbeddedTomcatServer(BASE_PACKAGE); // 创建Tomcat服务器实例

        JavelinHost.initNHttpApplication();

        applicationInit();

        System.out.println(" Javelin initialized!");

        server.start();

    }

    private void javelinInit()
    {
        loadStarters();

        for (BaseAppStarter starter : starters) {
            try {
                starter.preJavelinInit(); // 调用preInit方法
            } catch (Exception e) {
                e.printStackTrace(); // 打印异常堆栈信息     
            }
        }

        JavelinInitializer.frameworkInit();

        for (BaseAppStarter starter : starters) {
            try {
                starter.postJavelinInit(); // 调用preInit方法
            } catch (Exception e) {
                e.printStackTrace(); // 打印异常堆栈信息     
            }
        }
    }

    private void applicationInit()
    {
        for (BaseAppStarter starter : starters) {
            try {
                starter.preApplicationInit(); // 调用preInit方法
            } catch (Exception e) {
                e.printStackTrace(); // 打印异常堆栈信息     
            }
        }

        JavelinInitializer.applicationInit();


        for (BaseAppStarter starter : starters) {
            try {
                starter.postApplicationInit(); // 调用preInit方法
            } catch (Exception e) {
                e.printStackTrace(); // 打印异常堆栈信息     
            }
        }
    }


    private void loadStarters() {
        Reflections reflections = new Reflections(BASE_PACKAGE);
        Set<Class<? extends BaseAppStarter>> starterClasses = reflections.getSubTypesOf(BaseAppStarter.class);

        for (Class<? extends BaseAppStarter> starterClass : starterClasses) {
            try {
                starters.add(starterClass.getDeclaredConstructor().newInstance());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


}
