package site.itprohub.javelin.startup;

public abstract class BaseAppStarter {
    public void preJavelinInit(){

    }

    public void postJavelinInit() {

    }

    public void preApplicationInit(){

    }

    public void postApplicationInit() {
        
    }
}
