package site.itprohub.javelin.http.tomcat;

import java.io.File;

import jakarta.servlet.ServletException;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;

public class JavelinEmbeddedTomcatServer {
    private final Tomcat tomcat;
    private final int port;

    private final String basePackage;

    public JavelinEmbeddedTomcatServer(String basePackage) {
        this(basePackage, 8080);
    }

    public JavelinEmbeddedTomcatServer(String basePackage, int port) {
        this.tomcat = new Tomcat();
        this.port = port;
        this.basePackage = basePackage;
    }

    public void start() throws LifecycleException, ServletException {
        tomcat.setPort(port);
        tomcat.setHostname("0.0.0.0");

        String baseDir = new File("tomcat").getAbsolutePath();
        tomcat.setBaseDir(baseDir);

        // 添加web应用Context
        String contextPath = "";
        String docBase = new File(".").getAbsolutePath();
        Context context = tomcat.addContext(contextPath, docBase);

        // 👇 强制初始化 Connector（这是关键！）
        tomcat.getConnector();
        
        // 添加自定义Servlet
        JavelinDispatcherServlet servlet = new JavelinDispatcherServlet(basePackage);
        tomcat.addServlet(contextPath, "Javelin", servlet);
        context.addServletMappingDecoded("/*", "Javelin");

        // 启动Tomcat
        tomcat.start();
        tomcat.getServer().await();
    }
}
