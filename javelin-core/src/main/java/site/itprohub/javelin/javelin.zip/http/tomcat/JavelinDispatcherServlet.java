package site.itprohub.javelin.http.tomcat;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import site.itprohub.javelin.http.Pipeline.ServletHttpContext;
import site.itprohub.javelin.rest.Router;

@WebServlet(urlPatterns = "/*", loadOnStartup = 1)
public class JavelinDispatcherServlet extends HttpServlet {

    private final String basePackage;

    private final Router router;

    public JavelinDispatcherServlet(String basePackage) { 
        this.basePackage = basePackage; // 初始化basePackage变量
        this.router = new Router(); // 初始化router变量
    }

    @Override
    public void init() throws ServletException {
        router.registerRoutes(basePackage);
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            ServletHttpContext context = new ServletHttpContext(req, resp); // 创建ServeletHttpContext实例
            router.handle(context); // 调用router的handle方法，传入ServeletHttpContext实例
        } catch (Exception e) { 
            // 捕获异常
            resp.setStatus(500);
            resp.getWriter().write("Internal Server Error");
        }
    }
    
}
